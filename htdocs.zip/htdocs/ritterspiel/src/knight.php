<?php
/**
* Initializes a new knight using the given parameters.
*
* @param string $name The name of the new knight
* @param int $strength The strength of the new Knight. Must be between 1 and 100
*/
class weapon {
    function __construct($weapon, $damage) {
        $this->weapon = $weapon;
        $this->damage = $damage;
    }
    function __toString() {
        return $this->weapon;
    }
}
class knight {
    function __construct($name,$weapon,$strength,$health) {
        $this->name = $name;
        $this->weapon = $weapon;
        $this->strength = $strength;
        $this->health = $health;
    }
    public function __toString() {
        return $this->name;
        return $this->weapon;
    }
/**
* Attack the knight given with the parameter $defendingKnight.
*
* An attack reduces the health of the defending knight by an amount
* depending on the attackers strength.
*
* @param $defendingKnight Knight the knight to be attacked
*/
    function attack($dk) {
        $dk->health = $dk->health-$this->strength;
    }
/**
* Method used to see whether this knight is still alive.
*
* A knight is alive as long as his health is greater than 0.
*
* @return bool True if the knight is still alive. False otherwise.
*/
    function isAlive() {
        if ($this->health > 1) {
            return true;
        }
        else {
            return false;
        }
    }
}
/**
* Creates a HTML String containing all information about this knight.
*
* @return string HTML string representing this knight.
*/
?>