<?php
	header('Location: fight.php');
?>