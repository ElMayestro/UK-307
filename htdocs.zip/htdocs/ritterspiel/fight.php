<!DOCTYPE html>
<html>

<head>
    <title>Fight Clup</title>
    <link rel="stylesheet" href="css/style.css" />
</head>

<body>
    <?php
        require_once 'src/knight.php';
        $knights = array(
            new knight('Pokahontas',' ', 0, 100),
            new knight('Aslak',' ' , 0, 100),
            new knight('Harz 4',' ' , 0, 100),
            new knight('Max', ' ',  0, 100),
            new knight('G', ' ', 0, 100),
            new knight('varshan der Hunnenkönig', ' ', 0, 100),
            new knight('Der Türke', ' ', 0, 100),
            new knight('Joël', ' ', 0, 100),
            new knight('Löffu', ' ', 0, 100),
            new knight('Öpfu', ' ', 0, 100),
            new knight('Adolf Hitler', ' ', 0, 100),
            new knight('Joiinti', ' ', 0, 100),
            new knight('Luke (with the Nuke)', ' ', 0, 100),
            new knight('Digga Nigga', ' ', 0, 100),
            new knight('Cheng Deng', ' ', 0, 100),
            new knight('DiniMam', ' ', 0, 100),
            new knight('SteinPapier', ' ', 0, 100)
            );
        $weapons = array(
            new weapon('sword', 10),
            new weapon('spear', 10),
            new weapon('pistol', 20),
            new weapon('sniper', 100),
            new weapon('fist', 3),
            new weapon('p90-tr', 50),
            new weapon('ak-47', 50),
            new weapon('bow & arrow', 15),
            new weapon('Zyklon B', 99),
            new weapon('Nunchakus', 8),
            new weapon('knife', 7)
        );
        foreach ($knights as $knight) {
            $rndWP = array_rand($weapons);
            $knight->strength = $weapons[$rndWP]->damage;
            $knight->weapon = $weapons[$rndWP]->weapon;
            echo '<p>'.$knight->name. ' - ' . $knight->weapon . ' - ' . $knight->strength . '</p><br>';
        };
        $roundCounter = 0;
    while (count($knights) > 1) {
        $roundCounter ++;
        echo "<h1>Round $roundCounter </h1>";
        echo '<div class="fight-message">';
        echo 'still alive is: ';
        foreach ($knights as $knight) {
            echo $knight.'  '." ";
        }
        echo '</div>';
        $fightingKnightsIndexes = array_rand($knights, 2);
        shuffle($fightingKnightsIndexes);
        $attackingKnight = $knights[$fightingKnightsIndexes[0]];
        $defendingKnight = $knights[$fightingKnightsIndexes[1]];
        echo $attackingKnight.'('.$attackingKnight->health.')'.' vs '.$defendingKnight.'('.$defendingKnight->health.')';
        $attackingKnight->attack($defendingKnight);
        if (!$defendingKnight->isAlive()) {
            unset($knights[$fightingKnightsIndexes[1]]);
        }
    }
    echo '<br>';
    echo '<h1>And the Winner is</h1>';
    echo '<div class="fight-message">';
    foreach ($knights as $k) {
        echo $k;
    }
    echo '</div>';
    ?>
</body>
</html>