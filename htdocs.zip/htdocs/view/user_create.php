<form class="form-horizontal" action="/user/doCreate" method="post">
	<div class="component" data-html="true">
		<div class="form-group">
		  <label class="col-md-2 control-label" for="firstName">Vorname</label>
		  <div class="col-md-4">
		  	<input id="firstName" name="firstName" type="text" placeholder="Vorname" class="form-control input-md" required>
		  </div>
        </div>   
		<div class="form-group">
		  <label class="col-md-2 control-label" for="lastName">Nachname</label>
		  <div class="col-md-4">
		  	<input id="lastName" name="lastName" type="text" placeholder="Nachname" class="form-control input-md" required>
		  </div>
		</div>
        <div class="form-group">
		  <label class="col-md-2 control-label" for="dateofbirth">Geburtsdatum</label>
		  <div class="col-md-4">
		  	<input id="dateofbirth" name="dateofbirth" type="date" placeholder="00.00.0000" class="form-control input-md" required>
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-md-2 control-label" for="email">Mail</label>
		  <div class="col-md-4">
		  	<input id="email" name="email" type="text" placeholder="Mail" class="form-control input-md" required>
		  </div>
		</div>
        <div class="form-group">
		  <label class="col-md-2 control-label" for="city">Wohnort</label>
		  <div class="col-md-4">
		  	<input id="city" name="city" type="text" placeholder="Wohnort" class="form-control input-md" required>
		  </div>
		</div>
        <div class="form-group">
		  <label class="col-md-2 control-label" for="plz">PLZ</label>
		  <div class="col-md-4">
		  	<input id="plz" name="plz" type="text" placeholder="PLZ" class="form-control input-md" required>
		  </div>
		</div>        
        <div class="form-group">
		  <label class="col-md-2 control-label" for="street">Strasse/Hausnummer</label>
		  <div class="col-md-4">
		  	<input id="street" name="street" type="text" placeholder="Strasse" class="form-control input-md" required>
            </div>
            <div class="col-md-4">
            <input id="streetnbr" name="streetnbr" type="text" placeholder="Hausnummer" class="form-control input-md" required>
		  </div>
		</div> 
        <div class="form-group">
		  <label class="col-md-2 control-label" for="password">Passwort</label>
		  <div class="col-md-4">
		  	<input id="password" name="password" type="password" placeholder="Passwort" class="form-control input-md" required>
		  </div>
		</div>
        <div class="form-group">
		  <label class="col-md-2 control-label" for="passwordb">Passwort bestätigen</label>
		  <div class="col-md-4">
		  	<input id="passwordb" name="passwordb" type="password" placeholder="Passwort" class="form-control input-md" required>
		  </div>
		</div>
        
        <script>
            $(function() {
                
                var PW = $('#password');
                var PWB = $('#passwordb');
                
                
                $('#send').on("click", function() {
                if(PW.val() == PWB.val()) {
                    if (PWB.val() != ""){
                    $('.form-horizontal').submit();
                    } else {
                        break;
                    }
                } else {
                    alert('Die Passwörter stimmen nicht überein.');
                }
            });
            }); 
        </script>
        
		<div class="form-group">
	      <label class="col-md-2 control-label" for="send">&nbsp;</label>
		  <div class="col-md-4">
		    <input id="create" name="create" type="submit" class="btn btn-primary">
		  </div>
		</div>
	</div>
</form>
