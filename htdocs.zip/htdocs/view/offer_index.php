<a href="/offer/search">Suche</a>
<a href="/offer/create">Create</a>