<form class="form-horizontal" action="/user/doLogin" method="post">
	<div class="component" data-html="true">
        <div class="form-group">
		  <label style="float: left">Username: <?php echo $username; ?></label>
		  <div class="col-md-4">
		  </div>
		</div>
        <div class="form-group">
		  <label style="float: left">Email: <?php echo $email; ?></label>
		  <div class="col-md-4">
		  </div>
		</div>
        <div class="form-group">
	      <label style="float: right">Credits: <?php echo $credits; ?></label>
		  <div class="col-md-4">
		  </div>
		</div>
	</div>
</form>