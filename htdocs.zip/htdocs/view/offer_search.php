<form class="form-horizontal" action="/offer/search" method="post">
    <div class="component" data-html="true">
    
        <div class="form-group">
		  <label class="col-md-2 control-label" for="city">von:</label>
             <div class="col-md-4">
            <input id="city" name="city" type="text" placeholder="Ort" class="form-control input-md" required>
            </div>
        </div>
        
        <div class="form-group">
		  <label class="col-md-2 control-label" for="city">nach:</label>
            <div class="col-md-4">
            <input id="city" name="city" type="text" placeholder="Ort" class="form-control input-md" required>
            </div>
        </div>
        
        <div class="form-group">
		  <label class="col-md-2 control-label" for="city">ab:</label>
            <div class="col-md-4">
            <input id="starttime" name="starttime" type="time" placeholder="Uhrzeit" class="form-control input-md" required>
            </div>
        </div>
        
        <div class="form-group">
	      <label class="col-md-2 control-label" for="send">&nbsp;</label>
		  <div class="col-md-4">
		    <input id="send" name="send" type="submit" value="suchen" class="btn btn-primary">
		  </div>
		</div>
        
    </div>
</form>