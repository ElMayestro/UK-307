<?php

    if($login) {
        echo 'you are logged in!';
        echo '<br>'.$user;
        echo '<br>'.$username;
        echo '<br>'.$dob;
        echo '<br>'.$email;
        echo '<br>'.$address_id;
        echo '<br>'.$credits;
    }
?>