<?php

require_once 'lib/Model.php';

/**
 * Das UserModel ist zuständig für alle Zugriffe auf die Tabelle "user".
 *
 * Die Ausführliche Dokumentation zu Models findest du in der Model Klasse.
 */
class UserModel extends Model
{
    /**
     * Diese Variable wird von der Klasse Model verwendet, um generische
     * Funktionen zur Verfügung zu stellen.
     */
    protected $tableName = 'user';

    /**
     * Erstellt einen neuen benutzer mit den gegebenen Werten.
     *
     * Das Passwort wird vor dem ausführen des Queries noch mit dem SHA1
     *  Algorythmus gehashed.
     *
     * @param $firstName Wert für die Spalte firstName
     * @param $lastName Wert für die Spalte lastName
     * @param $email Wert für die Spalte email
     * @param $password Wert für die Spalte password
     *
     * @throws Exception falls das Ausführen des Statements fehlschlägt
     */
    public function create($firstName, $lastName, $dateofbirth, $email, $city, $plz, $street, $streetnbr, $password )
    {
        $password = sha1($password); //Password verschlüsseln
        $credits = "0"; //SET credits Guthaben auf null
        
        //USER -> firstName/lastName/dateofBirth/Email/password/credits
        //ADDRESS -> street/streetnbr/city
        $queryUSER = "INSERT INTO user (firstName, lastName, dateofbirth, email,  address_id, password, credits) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $queryADDRESS = "INSERT INTO address (street, streetnbr, city_id) VALUES (?, ?, ?)";
        $queryCITYSEL = "SELECT id FROM city WHERE name=?";
        $queryCITY = "INSERT INTO city (plz, name) VALUES (?, ?)";
        
        $statementCITYSEL = ConnectionHandler::getConnection()->prepare($queryCITYSEL);
        $statementCITYSEL->bind_param('s', $city);
        $statementCITYSEL->execute();
        $resultCITYSEL = $statementCITYSEL->get_result();
        $rowCITYSEL = $resultCITYSEL->fetch_object();
        if (!$rowCITYSEL) {
            //CREATE CITY
            $statementCITY = ConnectionHandler::getConnection()->prepare($queryCITY);
            $statementCITY->bind_param('is', $plz, $city);
            $statementCITY->execute();
            $resultCITY = $statementCITY->get_result();
            $rowCITY = $resultCITY;
            //GET CREATED CITY ID
            $queryCITYSEL = ConnectionHandler::getConnection()->prepare($querySELECTCITID);
            $queryCITYSEL->bind_param('s', $city);
            $queryCITYSEL->execute();
            $result = $queryCITYSEL->get_result();
            if (!$result) {
                throw new Exception($queryCITYSEL->error);
            }
            $rowCITYID = $result->fetch_object();
            $city_id = $rowCITYID->id;
        } else {
            $city_id = $rowCITYSEL->id;
        }
        
        $statementADDRESS = ConnectionHandler::getConnection()->prepare($queryADDRESS);
        $statementADDRESS->bind_param('sii', $street, $streetnbr, $city_id);
         if (!$statementADDRESS->execute()) {
            throw new Exception($statementADDRESS->error);
        }
        
        $querySELECTADDID = "SELECT id FROM address WHERE street=? AND streetnbr=? AND city_id=?";
        $statementSELECTADDID = ConnectionHandler::getConnection()->prepare($querySELECTADDID);
        $statementSELECTADDID->bind_param('ssi', $street, $streetnbr, $city_id);
        $statementSELECTADDID->execute();
        $result = $statementSELECTADDID->get_result();
        if (!$result) {
            throw new Exception($statementSELECTADDID->error);
        }
        $row = $result->fetch_object();
        $address_id = $row->id;
        
        $statementUSER = ConnectionHandler::getConnection()->prepare($queryUSER);
        $statementUSER->bind_param('ssssisi', $firstName, $lastName, $dateofbirth, $email, $address_id, $password, $credits);
        if (!$statementUSER->execute()) {
            throw new Exception($statementUSER->error);
        }
    }
    
    public function login($email, $password) {
        $pw = sha1($password);
        $queryLOGIN = "SELECT * FROM user WHERE email=?";
        $statementUSER = ConnectionHandler::getConnection()->prepare($queryLOGIN);
        $statementUSER->bind_param('s', $email);
        $statementUSER->execute();
        $result = $statementUSER->get_result();
        if (!$result) {
            throw new Exception($statementLOGIN->error);
        }
        $row = $result->fetch_object();
        $rpw = $row->password;
        $result->close();
        if ($rpw == $pw) {
            session_start();
            $_SESSION['user'] = $row->id;
            $_SESSION['username'] = $row->firstname.$row->lastname;
            $_SESSION['dob'] = $row->dateofbirth;
            $_SESSION['email'] = $email;
            $_SESSION['address_id'] = $row->address_id;
            $_SESSION['credits'] = $row->credits;
        }
    }
}
