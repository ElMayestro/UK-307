<?php

return array(

    'database' => array(
        'host' => 'localhost',
        'username' => 'exec',
        'password' => 'gibbiX12345',
        'database' => 'dnd',
    ),

);
