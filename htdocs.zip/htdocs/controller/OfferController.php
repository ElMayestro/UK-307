<?php
require_once 'model/OfferModel.php';

/**
 * Siehe Dokumentation im DefaultController.
 */
class OfferController
{
    public function index()
    {
        $offerModel = new OfferModel();

        $view = new View('offer_index');
        $view->title = 'Offers';
        $view->heading = 'Offers';
        $view->display();
    }
    
    public function search() {
        $offerModel = new OfferModel();
        
        $view = new View('offer_search');
        $view->title = 'Search';
        $view->heading = 'Search Offer';
        $view->display();
    }
    
    public function doSearch() {
        
    }
    
    public function create() {
        $offerModel = new OfferModel();
        
        $view = new View('offer_create');
        $view->title = 'Create Offer';
        $view->heading = 'Create Offer';
        $view->display();
    }
    
    public function doCreate() {
        
    }
}