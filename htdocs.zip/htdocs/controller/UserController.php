<?php
require_once 'model/UserModel.php';

/**
 * Siehe Dokumentation im DefaultController.
 */
class UserController
{
    public function index()
    {
        $userModel = new UserModel();

        $view = new View('user_account');
        $view->title = 'My Account';
        $view->heading = 'Account Settings';
        $view->users = $userModel->readAll();
        $view->display();
    }
    
    public function login() {
        $view = new View('user_login');
        $view->title = 'Login';
        $view->heading = 'Login';
        $view->display();
    }
    
    public function doLogin() {
        
        if ($_POST['doLogin']) {
            $email = $_POST['email'];
            $password = $_POST['password'];
            $_SESSION['tried'] = true;
            $userModel = new UserModel();
            $userModel->login($email, $password);
        }
        header('Location: /');
    }
    
    public function logout() {
        session_start();
        unset($GLOBALS['user']);
        session_destroy();
        header('Location: /');
    }

    public function create()
    {
        $view = new View('user_create');
        $view->title = 'Benutzer erstellen';
        $view->heading = 'Benutzer erstellen';
        $view->display();
    }

    public function doCreate()
    {
        if ($_POST['create']) {
            $firstName = $_POST['firstName'];
            $lastName = $_POST['lastName'];
            $dateofbirth = $_POST['dateofbirth'];
            $email = $_POST['email'];
            $city = $_POST['city'];
            $plz = $_POST['plz'];
            $street = $_POST['street'];
            $streetnbr = $_POST['streetnbr'];
            $password = $_POST['password'];
            
            $userModel = new UserModel();
            $userModel->create($firstName, $lastName, $dateofbirth, $email, $city, $plz, $street, $streetnbr,  $password);
        }

        // Anfrage an die URI /user weiterleiten (HTTP 302)
        header('Location: /user/login');
    }

    public function delete()
    {
        $userModel = new UserModel();
        $userModel->deleteById($_GET['id']);

        // Anfrage an die URI /user weiterleiten (HTTP 302)
        header('Location: /user');
    }
}
